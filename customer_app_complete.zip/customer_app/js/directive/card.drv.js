(function() {
	angular.module("directive_module",[]);

	angular.module("directive_module").directive("cardView", function(){
		return {
			templateUrl : 'js/templ/card.tmpl.html',
			restrict : 'E',
			scope : {
				first : '=',
				second : '=',
				desc : '=',
				pic : '=image',
				delete : '&',
				openEdit : '&'
			}
		}
	});
})();