(function(){
	var ng = angular.module("customer_module",["directive_module","service_module"]);

	ng.controller("CustomerMenuController", function($rootScope, $scope){
		$scope.searchText = "";
		$scope.filterCustomers = function() {
			$rootScope.$broadcast("filter_event",$scope.searchText);
		}
	});

	ng.controller("CustomerListController", function($scope, CustomerService ){
		// Asynchronous 
		CustomerService.getCustomers().then(function(result){
			$scope.customers = customers = result.data;
		});
		
		// Sync
		// $scope.customers = customers =  CustomerService.getCustomers();
		
		$scope.editMode = false;

		$scope.$on("filter_event", function(evt, txt){
			var result = [];
			customers.forEach(function(c){
				if(c.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0 ||
					c.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0) {
					result.push(c);
				}
			});

			$scope.customers = result;
		});


		$scope.openEdit = function(customer) {
			$scope.currentCustomer = customer;
			$scope.editMode = true;
		}

		$scope.update = function() {
			// server hit
			CustomerService.updateCustomer($scope.currentCustomer.id, $scope.currentCustomer);
			$scope.editMode = false;
		}
		$scope.deleteCustomer = function(id){
			// delete from server
			var idx = -1;
			$scope.customers.forEach(function(c,index){
				if(c.id == id) {
					idx = index;
					CustomerService.deleteCustomer(c.id);
				}
			});

			if(idx != -1) {
				$scope.customers.splice(idx, 1);
			}
		}
	});

})();