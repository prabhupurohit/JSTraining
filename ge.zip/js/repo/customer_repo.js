define(["model/customer"],function(Customer){
	var customers = [];
	var addCustomer = function(id, name) {
		customers.push(new Customer(id, name));
	};

	var getCustomers = function() {
			return customers;
	};

	var init = function() {
			customers.push(new Customer(1,"A"));
			customers.push(new Customer(2,"B"));
			customers.push(new Customer(3,"C"));
	}
	return {
		add : addCustomer,
		get : getCustomers,
		init: init
	}
});