Day 3
jQuery
-------

jQuery is a JavaScript Library.
Why jQuery?
1) jQuery provides a unified DOM interface.
	Each browser has slightly different DOM interface.
	jQuery uses CSS selectors

	.del {

	}

	#el {

	}

	h1 {

	}
2)  jQuery simplifes
	a) DOM traversing
	b) Manipulation
	c) listen to changes on DOM
	d) network calls [ AJAX ]

3) Global object [jQuery or $]

4) DOM ready function

	$(function(){

	});

	or

	$(document).ready(function() {

	});


-------

Select an element by ID:
$("#mylist")

select emelemt by tag name:
$("li")

select elements within other
$("#mylist li")

$("#mylist > li")

select first li:
$("#mylist > li:first")

select last li:
$("#mylist > li:last")

get and set text:
$("#mylist > li:first").text()
$("#mylist > li:first").text("Pepsi")

Apply CSS:
$("#mylist > li:even").css({"color":"red"})

---------------------------------------------------------------

RESTful web services
		
		Representational State Transfer
		Resource on Server needs to be deleivered to client in various 
		representation based on his request.
		Represetntations:
			JSON
			XML
			ATOM, RSS feed
			HTML
			plain text, csv

		http protocol
			uses URI to identify the resource
			uses HTTP methods to identify the actions

		CRUD ---> Create Read Update and Delete

		GET [ fetch all employees ]
		http://ge.com/employees

		GET [ fetch employee 100 ]
		http://ge.com/employees/100  <-- extra path parameter is id

		GET [ fetch all employees working in bangalore ]
		http://ge.com/employees?place=bangalore <-- Query param for any other criteria

		you need to set "accept" http header

		"accept": "application/json"

		"accept": "text/xml"

		---------

		POST
			is to create a sub-resource on the server
		http://ge.com/employees
			Payload contains the new employee data
			"contentType" : "application/json"

		Swagger

		-------------

		PUT or PATCH
			is to modify the content or create a sub-resource
			http://ge.com/employees/200
			extra path paramater is for employee id to be modified
			Payload contains the new employee data
			"contentType" : "application/json"

		----------

		DELETE
			http://ge.com/employees/134
			No Payload  
		------------------------------

		jQuery AJAX

		http://jsonplaceholder.typicode.com/

		npm install -g json-server

		json-server --port 9000 --static . --watch data.json
--------------------------------------------------------------------

Templates:

Server Side Templates							Client Side Templates
EJS 													Underscore	 <%= firstName %>
JADE 													Mustache     {{firstName}}
JSP 													Handlebars   #firstName
PHP 													
ASP.NET


	<%
		for(i = 0 ;i < 10 ; i++) {

	%>

		<li> <%= i %> </li>
	<%
		}
	%>

		


